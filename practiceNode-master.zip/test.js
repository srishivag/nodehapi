function fun1(){
    console.log("fun1");
}
var fun1=()=>{
console.log("function1")
}

fun1();