require('babel-core/register')
require('./src/server')